package encapsulation;

public class Car {
    String pemilik;
    private String Merk;
    public int kapasitas;
    protected int jumlahBan;

    public String getMerk() {
        return Merk;
    }

}