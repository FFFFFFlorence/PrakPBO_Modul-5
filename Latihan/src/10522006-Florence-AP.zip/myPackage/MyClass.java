package myPackage;

public class MyClass {
    public static void sayHello() { 
        System.out.println("Hello, nama aku Anton");
    }
}
